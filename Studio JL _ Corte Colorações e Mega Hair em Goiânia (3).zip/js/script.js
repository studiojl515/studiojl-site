/* STUDIO JL — comportamento do site (JavaScript puro, sem dependências) */
(function () {
  "use strict";

  var CFG = window.STUDIO_JL || {};
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- WhatsApp: monta todos os links a partir da configuração ---------- */
  function waLink(message) {
    return "https://wa.me/" + CFG.whatsapp + "?text=" + encodeURIComponent(message || CFG.whatsappMessage);
  }
  $$("[data-wa]").forEach(function (a) {
    a.href = waLink(a.getAttribute("data-wa-msg"));
  });
  $$("[data-wa-display]").forEach(function (el) { el.textContent = CFG.whatsappDisplay; });
  $$("[data-instagram]").forEach(function (a) { a.href = CFG.instagram; });
  $$("[data-instagram-handle]").forEach(function (el) { el.textContent = CFG.instagramHandle; });
  $$("[data-maps]").forEach(function (a) { a.href = CFG.maps; });
  $$("[data-maps-dir]").forEach(function (a) { a.href = CFG.mapsDirections; });

  /* ---------- Horários (renderizados a partir de config.js) ---------- */
  var today = new Date().getDay();
  $$("[data-hours]").forEach(function (list) {
    (CFG.hours || []).forEach(function (h) {
      var li = document.createElement("li");
      li.className = "hours__row hours__row--" + h.status + (h.dow === today ? " is-today" : "");
      var d = document.createElement("span");
      d.className = "hours__day";
      d.textContent = h.day;
      var t = document.createElement("span");
      t.className = "hours__time";
      t.textContent = h.status === "open" ? h.time : h.status === "closed" ? "Fechado" : "Horário a confirmar";
      li.appendChild(d);
      li.appendChild(t);
      if (h.dow === today) li.setAttribute("aria-current", "date");
      list.appendChild(li);
    });
  });

  /* ---------- Ano no rodapé ---------- */
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- Imagens ausentes → espaço reservado elegante ---------- */
  $$("img.ph-img").forEach(function (img) {
    function mark() {
      var box = img.closest(".ph");
      if (box) box.classList.add("is-missing");
    }
    if (img.complete && img.naturalWidth === 0) mark();
    img.addEventListener("error", mark);
  });

  /* ---------- Cabeçalho e menu mobile ---------- */
  var header = $(".site-header");
  var toggle = $(".nav-toggle");
  var nav = $("#menu");

  function setMenu(open) {
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
    nav.classList.toggle("is-open", open);
    document.body.classList.toggle("menu-open", open);
  }
  toggle.addEventListener("click", function () {
    setMenu(toggle.getAttribute("aria-expanded") !== "true");
  });
  $$("a", nav).forEach(function (a) {
    a.addEventListener("click", function () { setMenu(false); });
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && nav.classList.contains("is-open")) {
      setMenu(false);
      toggle.focus();
    }
  });
  window.matchMedia("(min-width: 960px)").addEventListener("change", function (e) {
    if (e.matches) setMenu(false);
  });

  function onScroll() { header.classList.toggle("is-scrolled", window.scrollY > 12); }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------- Link ativo no menu ---------- */
  var links = $$(".nav__link");
  if ("IntersectionObserver" in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        links.forEach(function (l) {
          var on = l.getAttribute("href") === "#" + en.target.id;
          l.classList.toggle("is-active", on);
          if (on) l.setAttribute("aria-current", "true"); else l.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    $$("main section[id]").forEach(function (s) { spy.observe(s); });
  }

  /* ---------- Animações ao rolar ---------- */
  var reveals = $$(".reveal");
  if ("IntersectionObserver" in window && !reduceMotion) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("is-in");
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add("is-in"); });
  }

  /* ---------- Galeria: filtros ---------- */
  var filters = $$(".filter");
  var items = $$(".g-item");
  filters.forEach(function (btn) {
    btn.addEventListener("click", function () {
      var cat = btn.getAttribute("data-filter");
      filters.forEach(function (b) { b.setAttribute("aria-pressed", String(b === btn)); });
      items.forEach(function (it) {
        var show = cat === "todos" || it.getAttribute("data-cat").split(" ").indexOf(cat) > -1;
        it.hidden = !show;
      });
      $(".g-grid").classList.toggle("is-filtered", cat !== "todos");
      var count = items.filter(function (i) { return !i.hidden; }).length;
      var live = $("#gallery-live");
      if (live) live.textContent = count + (count === 1 ? " foto exibida" : " fotos exibidas");
    });
  });

  /* ---------- Galeria: visualização ampliada ---------- */
  var dlg = $("#lightbox");
  var lbImg = $("#lb-img");
  var lbPh = $("#lb-ph");
  var lbCap = $("#lb-cap");
  var current = -1;
  var opener = null;

  function visibleItems() { return items.filter(function (i) { return !i.hidden; }); }

  function show(idx) {
    var list = visibleItems();
    if (!list.length) return;
    current = (idx + list.length) % list.length;
    var btn = $(".g-btn", list[current]);
    var img = $("img", btn);
    var label = $(".ph", btn).getAttribute("data-label");
    var missing = $(".ph", btn).classList.contains("is-missing");
    lbCap.textContent = label + "  ·  " + (current + 1) + " / " + list.length;
    if (missing) {
      lbImg.hidden = true;
      lbPh.hidden = false;
      lbPh.textContent = label;
    } else {
      lbPh.hidden = true;
      lbImg.hidden = false;
      lbImg.src = img.currentSrc || img.src;
      lbImg.alt = img.alt;
    }
  }

  function openLb(btn) {
    var list = visibleItems();
    opener = btn;
    dlg.showModal();
    document.body.classList.add("menu-open");
    show(list.indexOf(btn.closest(".g-item")));
  }
  function closeLb() { if (dlg.open) dlg.close(); }

  if (dlg && typeof dlg.showModal === "function") {
    $$(".g-btn").forEach(function (b) { b.addEventListener("click", function () { openLb(b); }); });
    $("#lb-close").addEventListener("click", closeLb);
    $("#lb-prev").addEventListener("click", function () { show(current - 1); });
    $("#lb-next").addEventListener("click", function () { show(current + 1); });
    dlg.addEventListener("click", function (e) { if (e.target === dlg) closeLb(); });
    dlg.addEventListener("close", function () {
      document.body.classList.remove("menu-open");
      if (opener) opener.focus();
    });
    dlg.addEventListener("keydown", function (e) {
      if (e.key === "ArrowLeft") show(current - 1);
      if (e.key === "ArrowRight") show(current + 1);
    });
    var x0 = null;
    dlg.addEventListener("touchstart", function (e) { x0 = e.changedTouches[0].clientX; }, { passive: true });
    dlg.addEventListener("touchend", function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) show(current + (dx < 0 ? 1 : -1));
      x0 = null;
    }, { passive: true });
  }
})();
