/* ==========================================================================
   STUDIO JL — CONFIGURAÇÃO EDITÁVEL
   Altere aqui os dados do estabelecimento. Não é preciso mexer no HTML
   para atualizar WhatsApp, horários ou links.
   ========================================================================== */
window.STUDIO_JL = {
  /* WhatsApp no padrão internacional brasileiro: 55 + DDD + número.
     Número confirmado pelo cliente: (62) 99863-4371 → 55 62 99863-4371. */
  whatsapp: "5562998634371",
  whatsappDisplay: "(62) 99863-4371",
  whatsappMessage:
    "Olá! Conheci o Studio JL pelo site e gostaria de saber mais sobre os serviços e horários disponíveis.",

  instagram: "https://www.instagram.com/studio_jl_hair/",
  instagramHandle: "@studio_jl_hair",

  /* Endereço oficial. Os links do Google Maps são gerados a partir dele. */
  address: "Av. Mangalô, 1182 - Quadra 10A, Lote 33 - St. Morada do Sol, Goiânia - GO, 74475-115",
  maps: "https://www.google.com/maps/search/?api=1&query=Av.%20Mangal%C3%B4%2C%201182%20-%20Quadra%2010A%2C%20Lote%2033%20-%20St.%20Morada%20do%20Sol%2C%20Goi%C3%A2nia%20-%20GO%2C%2074475-115",
  mapsDirections: "https://www.google.com/maps/dir/?api=1&destination=Av.%20Mangal%C3%B4%2C%201182%20-%20Quadra%2010A%2C%20Lote%2033%20-%20St.%20Morada%20do%20Sol%2C%20Goi%C3%A2nia%20-%20GO%2C%2074475-115",

  /* Horários. status: "open" | "closed" | "tbd" (a confirmar).
     dow segue Date.getDay(): 0 = domingo … 6 = sábado. */
  hours: [
    { dow: 1, day: "Segunda-feira", status: "closed" },
    { dow: 2, day: "Terça-feira",   status: "open", time: "09h às 18h" },
    { dow: 3, day: "Quarta-feira",  status: "open", time: "09h às 18h" },
    { dow: 4, day: "Quinta-feira",  status: "open", time: "09h às 18h" },
    { dow: 5, day: "Sexta-feira",   status: "open", time: "09h às 18h" },
    { dow: 6, day: "Sábado",        status: "open", time: "09h às 18h" },
    { dow: 0, day: "Domingo",       status: "closed" }
  ]
};
